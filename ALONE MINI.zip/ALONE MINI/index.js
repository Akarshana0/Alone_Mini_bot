require('dotenv').config();

const express = require('express');
const QRCode = require('qrcode');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  isJidGroup,
  jidNormalizedUser,
} = require('@whiskeysockets/baileys');

const config = require('./config');
const logger = require('./logger');
const { connectDB } = require('./utils/database');
const { rateLimitCheck } = require('./middleware/rateLimiter');
const { isOwner, pickText } = require('./utils/helpers');
const { menuText } = require('./commands/menu');
const { chatAI } = require('./commands/ai');

let sock;
let lastQR = null;
let dbEnabled = false;

let User = null;
try { User = require('./models/User'); } catch (_) {}

async function ensureUser(jid) {
  if (!dbEnabled || !User) return null;
  return User.findOneAndUpdate(
    { jid },
    {
      $setOnInsert: {
        jid,
        settings: {
          autoReact: config.DEFAULTS.AUTO_REACT,
          antiSpam: config.DEFAULTS.ANTI_SPAM,
          workType: config.DEFAULTS.WORK_TYPE,
        },
        stats: { commandsUsed: 0, lastSeenAt: null }
      }
    },
    { upsert: true, new: true }
  );
}

async function bumpStats(jid) {
  if (!dbEnabled || !User) return;
  await User.updateOne(
    { jid },
    { $inc: { 'stats.commandsUsed': 1 }, $set: { 'stats.lastSeenAt': new Date() } },
    { upsert: true }
  );
}

async function startSock() {
  dbEnabled = await connectDB();

  const { state, saveCreds } = await useMultiFileAuthState('./auth_info_baileys');

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
    logger,
    browser: [config.BOT_NAME, 'Chrome', '1.0.0'],
    markOnlineOnConnect: true,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (u) => {
    const { connection, lastDisconnect, qr } = u;

    if (qr) {
      lastQR = qr;
      logger.info('QR updated. Use /pair/94714768679 endpoint to view as image.');
    }

    if (connection === 'open') {
      logger.info('WhatsApp connected.');
    }

    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = code !== DisconnectReason.loggedOut;
      logger.warn({ code }, 'Connection closed');
      if (shouldReconnect) {
        startSock().catch((e) => logger.error({ err: e }, 'Reconnect failed'));
      }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages?.[0];
    if (!msg?.message) return;
    if (msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const sender = jidNormalizedUser(msg.key.participant || jid);
    const text = pickText(msg).trim();

    if (!text.startsWith(config.PREFIX)) return;

    const rl = rateLimitCheck(sender);
    if (rl.limited && !isOwner(sender)) {
      await sock.sendMessage(jid, { text: `⚠️ Rate limit exceeded. Try again in ${rl.resetInSec}s.` }, { quoted: msg });
      return;
    }

    const userDoc = await ensureUser(sender);
    await bumpStats(sender);

    const reactEnabled = userDoc?.settings?.autoReact ?? config.DEFAULTS.AUTO_REACT;
    const react = async (emoji) => {
      if (!reactEnabled) return;
      try {
        await sock.sendMessage(jid, { react: { text: emoji, key: msg.key } });
      } catch (_) {}
    };

    const reply = async (t) => sock.sendMessage(jid, { text: t }, { quoted: msg });

    const body = text.slice(config.PREFIX.length).trim();
    const parts = body.split(/\s+/);
    const cmd = (parts.shift() || '').toLowerCase();
    const args = parts;

    try {
      switch (cmd) {
        case 'menu':
        case 'help':
          await react('✅');
          return reply(menuText());

        case 'ping':
          await react('🔥');
          return reply('🏓 Pong');

        case 'alive':
          await react('✅');
          return reply(`✅ ${config.BOT_NAME} is alive! Uptime: ${Math.floor(process.uptime())}s`);

        case 'owner':
          await react('✅');
          return reply(`Owner: AKARSHANA\nNumber: ${config.OWNER_NUMBER}`);

        case 'ai': {
          await react('⏳');
          const out = await chatAI(args.join(' '));
          await react(out.startsWith('⚠️') ? '❌' : '✅');
          return reply(out);
        }

        case 'settings': {
          await react('✅');
          const ar = userDoc?.settings?.autoReact ?? config.DEFAULTS.AUTO_REACT;
          const as = userDoc?.settings?.antiSpam ?? config.DEFAULTS.ANTI_SPAM;
          const wt = userDoc?.settings?.workType ?? config.DEFAULTS.WORK_TYPE;
          return reply(`⚙️ Settings\nAutoReact: ${ar ? 'ON' : 'OFF'}\nAntiSpam: ${as ? 'ON' : 'OFF'}\nWorkType: ${wt}\n\nOwner toggles: .autoreact / .antispam / .worktype public|private`);
        }

        case 'autoreact': {
          if (!isOwner(sender)) return reply('⚠️ Owner only.');
          if (!dbEnabled || !User) return reply('⚠️ MongoDB disabled (set MONGOURI).');
          const cur = userDoc?.settings?.autoReact ?? config.DEFAULTS.AUTO_REACT;
          await User.updateOne({ jid: sender }, { $set: { 'settings.autoReact': !cur } }, { upsert: true });
          await react('✅');
          return reply(`✅ AutoReact: ${!cur ? 'ON' : 'OFF'}`);
        }

        case 'antispam': {
          if (!isOwner(sender)) return reply('⚠️ Owner only.');
          if (!dbEnabled || !User) return reply('⚠️ MongoDB disabled (set MONGOURI).');
          const cur = userDoc?.settings?.antiSpam ?? config.DEFAULTS.ANTI_SPAM;
          await User.updateOne({ jid: sender }, { $set: { 'settings.antiSpam': !cur } }, { upsert: true });
          await react('✅');
          return reply(`✅ AntiSpam: ${!cur ? 'ON' : 'OFF'}`);
        }

        case 'worktype': {
          if (!isOwner(sender)) return reply('⚠️ Owner only.');
          if (!dbEnabled || !User) return reply('⚠️ MongoDB disabled (set MONGOURI).');
          const v = (args[0] || '').toLowerCase();
          if (!['public', 'private'].includes(v)) return reply('Usage: .worktype public|private');
          await User.updateOne({ jid: sender }, { $set: { 'settings.workType': v } }, { upsert: true });
          await react('✅');
          return reply(`✅ WorkType: ${v}`);
        }

        // ===== Group commands (need bot admin in group) =====
        case 'add': {
          if (!isJidGroup(jid)) return reply('⚠️ Group only.');
          const num = (args[0] || '').replace(/\D/g, '');
          if (!num) return reply('Usage: .add 947xxxxxxxx');
          await sock.groupParticipantsUpdate(jid, [`${num}@s.whatsapp.net`], 'add');
          await react('✅');
          return;
        }

        case 'kick':
        case 'remove': {
          if (!isJidGroup(jid)) return reply('⚠️ Group only.');
          const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
          if (!mentioned.length) return reply('⚠️ Mention user to remove.');
          await sock.groupParticipantsUpdate(jid, mentioned, 'remove');
          await react('✅');
          return;
        }

        case 'promote': {
          if (!isJidGroup(jid)) return reply('⚠️ Group only.');
          const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
          if (!mentioned.length) return reply('⚠️ Mention user to promote.');
          await sock.groupParticipantsUpdate(jid, mentioned, 'promote');
          await react('✅');
          return;
        }

        case 'demote': {
          if (!isJidGroup(jid)) return reply('⚠️ Group only.');
          const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
          if (!mentioned.length) return reply('⚠️ Mention user to demote.');
          await sock.groupParticipantsUpdate(jid, mentioned, 'demote');
          await react('✅');
          return;
        }

        case 'tagall':
        case 'hidetag': {
          if (!isJidGroup(jid)) return reply('⚠️ Group only.');
          const meta = await sock.groupMetadata(jid);
          const members = meta.participants.map(p => p.id);
          const message = args.join(' ') || 'Hello everyone!';
          const out = message + "\n\n" + members.map(m => '@' + m.split('@')[0]).join(' ');
          await sock.sendMessage(jid, { text: out, mentions: members });
          await react('✅');
          return;
        }

        default:
          await react('❓');
          return reply('Unknown command. Type .menu');
      }
    } catch (e) {
      logger.error({ err: e }, 'Command failed');
      await react('❌');
      return reply('⚠️ Error occurred. Check logs.');
    }
  });
}

// ===== Express server =====
const app = express();

app.get('/', (req, res) => {
  res.json({ name: config.BOT_NAME, status: sock ? 'running' : 'starting', uptime: Math.floor(process.uptime()) });
});

// Pair endpoint: /pair/94714768679
app.get('/pair/:number', async (req, res) => {
  if (req.params.number !== config.OWNER_NUMBER) {
    return res.status(403).json({ error: 'Unauthorized number' });
  }
  if (!lastQR) {
    return res.status(202).json({ message: 'QR not ready yet. Refresh in a few seconds.' });
  }
  try {
    const dataUrl = await QRCode.toDataURL(lastQR);
    return res.json({ qr: dataUrl });
  } catch (e) {
    return res.status(500).json({ error: 'Failed to generate QR' });
  }
});

app.listen(config.PORT, () => {
  logger.info(`Express listening on :${config.PORT}`);
  startSock().catch((e) => logger.error({ err: e }, 'Startup failed'));
});
