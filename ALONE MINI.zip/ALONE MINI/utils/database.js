const mongoose = require('mongoose');
const logger = require('../logger');
const config = require('../config');

async function connectDB() {
  if (!config.MONGOURI) {
    logger.warn('MONGOURI not set; MongoDB features disabled.');
    return false;
  }
  try {
    await mongoose.connect(config.MONGOURI, { serverSelectionTimeoutMS: 7000 });
    logger.info('MongoDB connected.');
    return true;
  } catch (e) {
    logger.error({ err: e }, 'MongoDB connection failed.');
    return false;
  }
}

module.exports = { connectDB };
