const config = require('../config');

function isOwner(jid) {
  return (jid || '').startsWith(config.OWNER_NUMBER);
}

function pickText(msg) {
  return msg?.message?.conversation
    || msg?.message?.extendedTextMessage?.text
    || msg?.message?.imageMessage?.caption
    || msg?.message?.videoMessage?.caption
    || '';
}

module.exports = { isOwner, pickText };
