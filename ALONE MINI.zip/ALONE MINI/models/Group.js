const mongoose = require('mongoose');

const groupSchema = new mongoose.Schema({
  jid: { type: String, required: true, unique: true, index: true },
  settings: {
    welcome: { type: Boolean, default: false },
    antiLink: { type: Boolean, default: false },
  },
}, { timestamps: true });

module.exports = mongoose.model('Group', groupSchema);
