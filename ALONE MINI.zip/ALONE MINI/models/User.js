const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  jid: { type: String, required: true, unique: true, index: true },
  settings: {
    autoReact: { type: Boolean, default: true },
    antiSpam: { type: Boolean, default: true },
    workType: { type: String, enum: ['public','private'], default: 'public' },
  },
  stats: {
    commandsUsed: { type: Number, default: 0 },
    lastSeenAt: { type: Date, default: null },
  },
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
