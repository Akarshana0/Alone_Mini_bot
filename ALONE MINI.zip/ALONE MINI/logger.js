const pino = require('pino');
const config = require('./config');

module.exports = pino({
  level: config.DEFAULTS.DEBUG ? 'debug' : 'info',
  transport: config.NODE_ENV !== 'production'
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'SYS:standard',
          ignore: 'pid,hostname'
        }
      }
    : undefined,
});
