const assert = require('assert');
const config = require('./config');

assert.ok(config.BOT_NAME);
assert.ok(config.PREFIX);
assert.strictEqual(config.OWNER_NUMBER, '94714768679');
console.log('✅ Basic tests passed');
