# Developer notes

- Entry: index.js
- Commands: commands/
- DB: models/ + utils/database.js
- Rate limit: middleware/rateLimiter.js
