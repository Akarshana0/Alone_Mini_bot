# ALONE MINI BOT (Heroku Ready)

**Bot Name:** ALONE MINI BOT  
**Owner:** AKARSHANA (94714768679)

## Run locally
1. npm install
2. cp .env.example .env
3. Fill MONGOURI and optional AI keys
4. npm start
5. Pair: http://localhost:3000/pair/94714768679

## Deploy on Heroku
- Create app and set Config Vars (same keys as .env.example)
- Deploy
- Pair: https://<app>.herokuapp.com/pair/94714768679

## Note
Use responsibly; WhatsApp may restrict unauthorized automation.
