# Heroku deploy (short)

1) Create Heroku app
2) Add Config Vars (Settings → Config Vars):
- MONGOURI
- OWNER_NUMBER=94714768679
- BOT_NAME=ALONE MINI BOT
- PREFIX=.
- optional: GROQ_API_KEY / OPENAI_API_KEY

3) Deploy
4) Pair endpoint:
- https://<app>.herokuapp.com/pair/94714768679
