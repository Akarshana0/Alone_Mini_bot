# Package summary

This zip includes a Heroku-ready Node.js project using Baileys + Express + MongoDB.
