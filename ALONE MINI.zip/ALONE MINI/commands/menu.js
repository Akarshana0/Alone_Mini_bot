const config = require('../config');

function menuText() {
  return `*${config.BOT_NAME}*
Owner: ${config.OWNER_NUMBER}
Prefix: ${config.PREFIX}

*Main*
- ${config.PREFIX}menu
- ${config.PREFIX}ping
- ${config.PREFIX}alive
- ${config.PREFIX}owner
- ${config.PREFIX}settings

*AI*
- ${config.PREFIX}ai <text>

*Settings (Owner only)*
- ${config.PREFIX}autoreact
- ${config.PREFIX}antispam
- ${config.PREFIX}worktype <public|private>

*Group*
- ${config.PREFIX}add 947xxxxxxxx
- ${config.PREFIX}kick @tag
- ${config.PREFIX}promote @tag
- ${config.PREFIX}demote @tag
- ${config.PREFIX}tagall <text>
- ${config.PREFIX}hidetag <text>

සිංහල/English support ✅`;
}

module.exports = { menuText };
