const axios = require('axios');
const config = require('../config');

async function chatAI(prompt) {
  const text = (prompt || '').trim();
  if (!text) return 'Usage: .ai <message>';

  if (config.APIS.GROQ_API_KEY) {
    try {
      const r = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model: 'mixtral-8x7b-32768',
        messages: [{ role: 'user', content: text }],
        max_tokens: 200,
      }, {
        headers: { Authorization: `Bearer ${config.APIS.GROQ_API_KEY}` },
        timeout: 20000,
      });
      return r.data.choices?.[0]?.message?.content?.trim() || 'No response.';
    } catch (_) {}
  }

  if (config.APIS.OPENAI_API_KEY) {
    try {
      const r = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: text }],
        max_tokens: 220,
      }, {
        headers: { Authorization: `Bearer ${config.APIS.OPENAI_API_KEY}` },
        timeout: 20000,
      });
      return r.data.choices?.[0]?.message?.content?.trim() || 'No response.';
    } catch (_) {
      return '⚠️ AI service error (check API key / quota).';
    }
  }

  return '⚠️ AI not configured. Set GROQ_API_KEY or OPENAI_API_KEY in .env.';
}

module.exports = { chatAI };
