require('dotenv').config();

module.exports = {
  BOT_NAME: process.env.BOT_NAME || 'ALONE MINI BOT',
  PREFIX: process.env.PREFIX || '.',
  OWNER_NUMBER: process.env.OWNER_NUMBER || '94714768679',
  PORT: Number(process.env.PORT || 3000),
  NODE_ENV: process.env.NODE_ENV || 'development',
  MONGOURI: process.env.MONGOURI,
  APIS: {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    GROQ_API_KEY: process.env.GROQ_API_KEY,
    ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
  },
  DEFAULTS: {
    AUTO_REACT: (process.env.AUTO_REACT || 'true') === 'true',
    ANTI_SPAM: (process.env.ANTI_SPAM || 'true') === 'true',
    WORK_TYPE: process.env.WORK_TYPE || 'public',
    MAX_COMMANDS_PER_HOUR: Number(process.env.MAX_COMMANDS_PER_HOUR || 50),
    DEBUG: (process.env.DEBUG || 'false') === 'true',
  }
};
