const NodeCache = require('node-cache');
const config = require('../config');

const cache = new NodeCache({ stdTTL: 60 * 60 });

function rateLimitCheck(jid) {
  const key = `rl:${jid}`;
  const v = cache.get(key) || { count: 0, resetAt: Date.now() + 3600000 };
  if (Date.now() > v.resetAt) {
    v.count = 0;
    v.resetAt = Date.now() + 3600000;
  }
  v.count += 1;
  cache.set(key, v);

  const limited = v.count > config.DEFAULTS.MAX_COMMANDS_PER_HOUR;
  return {
    limited,
    remaining: Math.max(0, config.DEFAULTS.MAX_COMMANDS_PER_HOUR - v.count),
    resetInSec: Math.max(0, Math.ceil((v.resetAt - Date.now()) / 1000))
  };
}

module.exports = { rateLimitCheck };
